import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, ShoppingCart } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  location?: string;
  category: 'crop' | 'input' | 'machinery';
  type?: string;
}

const ProductCard: React.FC<ProductCardProps> = ({
  id,
  name,
  price,
  image,
  description,
  location,
  category,
  type
}) => {
  const { addItem, state } = useCart();
  const { toast } = useToast();

  const handleAddToCart = () => {
    if (!state.isLoggedIn) {
      toast({
        title: "Login Required",
        description: "Please login to add items to cart",
        variant: "destructive",
      });
      return;
    }

    addItem({
      id,
      name,
      price,
      image,
      category
    });

    toast({
      title: "Added to Cart",
      description: `${name} has been added to your cart`,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -8, scale: 1.02 }}
    >
      <Card className="h-full flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border-0 bg-white">
        <div className="relative overflow-hidden">
          <img
            src={image}
            alt={name}
            className="w-full h-56 object-cover transition-transform duration-300 hover:scale-110"
            onError={(e) => {
              (e.target as HTMLImageElement).src = '/api/placeholder/300/200';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300" />
          {type && (
            <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground font-semibold">
              {type.toUpperCase()}
            </Badge>
          )}
          <div className="absolute bottom-3 left-3">
            <Badge variant="secondary" className="bg-white/90 text-foreground font-medium">
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Badge>
          </div>
        </div>
        
        <CardContent className="flex-1 p-6 flex flex-col">
          <div className="flex-1">
            <h3 className="font-bold text-xl mb-3 text-foreground leading-tight">
              {name}
            </h3>
            <p className="text-muted-foreground text-sm mb-4 line-clamp-2 leading-relaxed">
              {description}
            </p>
            
            {location && (
              <div className="flex items-center text-sm text-muted-foreground mb-4">
                <MapPin className="h-4 w-4 mr-2 text-primary" />
                <span className="font-medium">{location}</span>
              </div>
            )}
          </div>
          
          <div className="mt-auto space-y-4">
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-3xl font-bold text-primary">
                  ₹{price.toLocaleString()}
                </span>
                {category === 'machinery' && (
                  <span className="text-sm text-muted-foreground ml-1">/day</span>
                )}
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-foreground">
                  {category === 'machinery' ? 'Rental Price' : 'Per Unit'}
                </div>
              </div>
            </div>
            
            <Button 
              onClick={handleAddToCart}
              className="w-full bg-primary hover:bg-primary-dark text-primary-foreground font-semibold py-3 rounded-lg transition-all duration-200 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={!state.isLoggedIn}
            >
              <ShoppingCart className="h-5 w-5 mr-2" />
              {!state.isLoggedIn 
                ? 'Login Required' 
                : category === 'machinery' 
                  ? 'Rent Now' 
                  : 'Add to Cart'
              }
            </Button>
            
            {!state.isLoggedIn && (
              <p className="text-xs text-center text-muted-foreground">
                Please login to add items to your cart
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProductCard;