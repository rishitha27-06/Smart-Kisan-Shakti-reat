import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Clock, ChevronRight, Globe } from 'lucide-react';
import { motion } from 'framer-motion';
import { articles } from '@/data/products';

const KnowledgeCenter = () => {
  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'hi' | 'te'>('en');

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'te', name: 'తెలుగు', flag: '🇮🇳' }
  ];

  const currentArticles = articles[selectedLanguage];

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Knowledge Center
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Access expert farming knowledge, tips, and best practices. 
            Learn from agricultural experts in your preferred language.
          </p>
        </motion.div>

        {/* Language Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-8"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Select Language
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                {languages.map((language) => (
                  <Button
                    key={language.code}
                    variant={selectedLanguage === language.code ? "default" : "outline"}
                    onClick={() => setSelectedLanguage(language.code as 'en' | 'hi' | 'te')}
                    className="flex items-center gap-2"
                  >
                    <span className="text-lg">{language.flag}</span>
                    {language.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Featured Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mb-12"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-primary text-primary-foreground">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-3xl mb-3">🌱</div>
                  <h3 className="font-semibold mb-2">Seasonal Tips</h3>
                  <p className="text-sm opacity-90">
                    Get timely advice for each farming season
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-leaf text-white">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-3xl mb-3">🚜</div>
                  <h3 className="font-semibold mb-2">Modern Techniques</h3>
                  <p className="text-sm opacity-90">
                    Learn about latest farming technologies
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-harvest text-foreground">
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-3xl mb-3">💡</div>
                  <h3 className="font-semibold mb-2">Expert Advice</h3>
                  <p className="text-sm opacity-90">
                    Get insights from agricultural experts
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Articles Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {currentArticles.map((article, index) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <Card className="h-full card-hover cursor-pointer group">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                          {article.title}
                        </CardTitle>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">{article.category}</Badge>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {article.readTime}
                          </div>
                        </div>
                      </div>
                      <BookOpen className="h-6 w-6 text-muted-foreground" />
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-muted-foreground text-sm line-clamp-3 mb-4">
                      {article.content}
                    </p>
                    
                    <Button variant="ghost" className="w-full justify-between group-hover:bg-primary/10">
                      Read More
                      <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Categories Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mb-12"
        >
          <Card>
            <CardHeader>
              <CardTitle>Knowledge Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { name: 'Crop Management', icon: '🌾', count: 12 },
                  { name: 'Soil Health', icon: '🌱', count: 8 },
                  { name: 'Pest Control', icon: '🐛', count: 15 },
                  { name: 'Irrigation', icon: '💧', count: 10 },
                  { name: 'Weather Tips', icon: '🌤️', count: 6 },
                  { name: 'Market Trends', icon: '📈', count: 9 },
                  { name: 'Organic Farming', icon: '🌿', count: 11 },
                  { name: 'Technology', icon: '🚜', count: 7 }
                ].map((category, index) => (
                  <motion.div
                    key={category.name}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="text-center p-4 border border-border rounded-lg hover:border-primary transition-colors cursor-pointer"
                  >
                    <div className="text-2xl mb-2">{category.icon}</div>
                    <h4 className="font-medium text-sm mb-1">{category.name}</h4>
                    <p className="text-xs text-muted-foreground">{category.count} articles</p>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
          className="text-center bg-primary rounded-2xl p-8"
        >
          <h2 className="text-2xl font-bold text-primary-foreground mb-4">
            Want to Contribute?
          </h2>
          <p className="text-primary-foreground/90 mb-6 max-w-2xl mx-auto">
            Share your farming knowledge and help fellow farmers. Your experience 
            can make a difference in someone's agricultural journey.
          </p>
          <Button size="lg" className="bg-primary-foreground text-primary hover:bg-primary-foreground/90">
            Share Your Knowledge
          </Button>
        </motion.div>
      </div>
    </div>
  );
};

export default KnowledgeCenter;